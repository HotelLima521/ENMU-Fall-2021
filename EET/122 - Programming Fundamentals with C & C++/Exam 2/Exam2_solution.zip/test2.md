3. The output would be "The value of z is: 25"

4. The output would be:

a= 10
b= 15

